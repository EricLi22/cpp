#ifndef MATH_H
#define  MATH_H
long pow(int base,int power);
#endif
